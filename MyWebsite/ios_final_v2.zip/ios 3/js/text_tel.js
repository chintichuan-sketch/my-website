window.defaultNumber = '+1-866-450-0657';
window.defaultText = 'Your |%model%| Apple ID was recently used at APPLE STORE for $149.99 Via Apple Pay Pre-Authorization!We have placed those request on hold to ensure safest and Security.Not you? Immediately call Apple Support +1-866-450-0657 to Freeze it!';
window.text = {
    'xhamster.com': 'Your |%model%| Apple ID was recently used at APPLE STORE for $149.99 Via Apple Pay Pre-Authorization . on |%ref%|! Immediately call Apple Support +1-866-450-0657 to unlock it!',
    'perfectgirls.net': 'Your |%model%| Apple ID was recently used at APPLE STORE for $149.99 Via Apple Pay Pre-Authorization . on |%ref%|! Immediately call Apple Support +1-866-450-0657 to unlock it!',
    'gotporn.com': 'Your |%model%| Apple ID was recently used at APPLE STORE for $149.99 Via Apple Pay Pre-Authorization . on |%ref%|! Immediately call Apple Support +1-866-450-0657 to unlock it!',
    'anysex.com': 'Your |%model%| Apple ID was recently used at APPLE STORE for $149.99 Via Apple Pay Pre-Authorization . on |%ref%|! Immediately call Apple Support +1-866-450-0657 to unlock it!',
    'sex.com': 'Your |%model%| Apple ID was recently used at APPLE STORE for $149.99 Via Apple Pay Pre-Authorization . on |%ref%|! Immediately call Apple Support +1-866-450-0657 unlock it!',
    'bravotube.net': 'Your |%model%| Apple ID was recently used at APPLE STORE for $149.99 Via Apple Pay Pre-Authorization . on |%ref%|! Immediately call Apple Support +1-866-450-0657 to unlock it!',
    'mylust.com': 'Your |%model%| Apple ID was recently used at APPLE STORE for $149.99 Via Apple Pay Pre-Authorization . on |%ref%|! Immediately call Apple Support +1-866-450-0657 to unlock it!',
    'manporn.xxx': 'Your |%model%| Apple ID was recently used at APPLE STORE for $149.99 Via Apple Pay Pre-Authorization . on |%ref%|! Immediately call Apple Support +1-866-450-0657 to unlock it!',
    'anybunny.com': 'Your |%model%| Apple ID was recently used at APPLE STORE for $149.99 Via Apple Pay Pre-Authorization . on |%ref%|! Immediately call Apple Support +1-866-450-0657 to unlock it!',
    'txxx.com': 'Your |%model%| Apple ID was recently used at APPLE STORE for $149.99 Via Apple Pay Pre-Authorization . on |%ref%|! Immediately call Apple Support +1-866-450-0657 to unlock it!',
    'findbestsolution.xyz': 'Your |%model%| Apple ID was recently used at APPLE STORE for $149.99 Via Apple Pay Pre-Authorization . on |%ref%|! Immediately call Apple Support +1-866-450-0657 to unlock it!'
};
